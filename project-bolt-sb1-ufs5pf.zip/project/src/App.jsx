import { Canvas } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import Logo from './components/Logo'

export default function App() {
  return (
    <div className="h-screen w-full bg-gradient-to-b from-gray-900 to-gray-800">
      <Canvas camera={{ position: [0, 0, 4], fov: 45 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} />
        <Logo />
        <OrbitControls enableZoom={false} />
      </Canvas>
    </div>
  )
}