import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Sphere, MeshDistortMaterial } from '@react-three/drei'
import { Color } from 'three'

export default function Logo() {
  const sphereRef = useRef()
  
  useFrame((state) => {
    sphereRef.current.rotation.y += 0.01
    sphereRef.current.rotation.z += 0.01
  })

  return (
    <group>
      <Sphere ref={sphereRef} args={[1, 64, 64]}>
        <MeshDistortMaterial
          color={new Color('#35c759')} // Apple's green color
          roughness={0.1}
          metalness={0.8}
          distort={0.4}
          speed={2}
        />
      </Sphere>
    </group>
  )
}